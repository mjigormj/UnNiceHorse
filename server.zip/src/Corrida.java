import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Corrida extends Thread {
    Socket clienteSocket;
    InputStream input;
    Scanner entrada;
    String nome;
    long[] tempoIncial = new long[5];
    long[] tempoFinal = new long[5];
    long[] tempoCavalo = new long[5];
    Random r = new Random();

    Validacao validacao = new Validacao();

    public Corrida(Socket socket) {
        clienteSocket = socket;
    }

    public static List<Integer> valoresRandomicos() {
        Random random = new Random();
        int numero;
        List<Integer> num = new ArrayList<>();
        while (num.size() < 5) {
            numero = random.nextInt(5);
            if (num.isEmpty() || !num.contains(numero)) {
                num.add(numero);
            }
        }
        return num;
    }

    @Override
    public void run() {

        try {
            Thread[] cavalo = new Thread[5];
            cavalo[0] = new Thread("Imperatriz");
            cavalo[1] = new Thread("Duque");
            cavalo[2] = new Thread("Princesa (vc sabe quem)");
            cavalo[3] = new Thread("Pé de Pano");
            cavalo[4] = new Thread("Pangaré");

            Scanner scanner = new Scanner(clienteSocket.getInputStream());
            int cavaloAposta = scanner.nextInt();
            CavaloEnum cavaloApostado = CavaloEnum.cavaloEscolhido(cavaloAposta);
            String valorAposta = scanner.nextLine();
            System.out.println("Primeiro Apostador escolheu: " + cavaloAposta + "-" + cavaloApostado + " Apostou: " + valorAposta);

            Thread.sleep(3 * 1);

            System.out.println("-*-Pista de 2km -*-");
            Thread.sleep(3 * 1);
            System.out.println("3...");
            Thread.sleep(1 * 1);
            System.out.println("2...");
            Thread.sleep(1 * 1);
            System.out.println("1...");
            Thread.sleep(1 * 1);
            System.out.println("Corrida iniciada!");

            List<Integer> num = new ArrayList<>();
            num = valoresRandomicos();
            num.forEach(i -> {
                cavalo[i].start();
                tempoIncial[i] = System.nanoTime();
            });

            num = valoresRandomicos();
            for (int i : num) {
                cavalo[i].join();
                tempoFinal[i] = System.nanoTime();
                tempoCavalo[i] = (tempoFinal[i] - tempoIncial[i]) / 10000;
            }

            long tempoCavalo1;
            long tempoCavalo2;
            long tempoCavalo3;
            long tempoCavalo4;
        
            tempoCavalo1 = tempoCavalo[0];
            tempoCavalo2 = tempoCavalo[1];
            tempoCavalo3 = tempoCavalo[2];
            tempoCavalo4 = tempoCavalo[3];

            List<Long> ranking = Arrays.asList(tempoCavalo[0], tempoCavalo[1], tempoCavalo[2], tempoCavalo[3], tempoCavalo[4]);
            Collections.sort(ranking);

            List<Object> rankingList = new ArrayList<>();

            for (Long teste : ranking) {
                if (teste == tempoCavalo1) {
                    rankingList.add(CavaloEnum.IMPERATRIZ.getNomeCavalo());
                    rankingList.add(teste);
                    System.out.println(CavaloEnum.IMPERATRIZ.getNomeCavalo()+ " " + teste );
                }
                else if(teste == tempoCavalo2){
                    rankingList.add(CavaloEnum.DUQUE.getNomeCavalo());
                    rankingList.add(teste);
                    System.out.println(CavaloEnum.DUQUE.getNomeCavalo()+ " " + teste );
                }
                else if(teste == tempoCavalo3){
                    rankingList.add(CavaloEnum.PRINCESA.getNomeCavalo());
                    rankingList.add(teste);
                    System.out.println(CavaloEnum.PRINCESA.getNomeCavalo()+ " " + teste );
                }
                else if(teste == tempoCavalo4){
                    rankingList.add(CavaloEnum.PE.getNomeCavalo());
                    rankingList.add(teste);
                    System.out.println(CavaloEnum.PE.getNomeCavalo()+ " " + teste );
                }
                else{
                    rankingList.add(CavaloEnum.PANGARE.getNomeCavalo());
                    rankingList.add(teste);
                    System.out.println(CavaloEnum.PANGARE.getNomeCavalo()+ " " + teste );
                }
            }

            try {
                Thread.sleep(r.nextInt(1000));
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            PrintStream printStream = new PrintStream(clienteSocket.getOutputStream());
            printStream.println(rankingList);

        } catch (Exception e) {
            System.out.println("Erro na thread: " + e.getMessage());
        }

        System.out.println("Corrida terminada !!!");
    }
}