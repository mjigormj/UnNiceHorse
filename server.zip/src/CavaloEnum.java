public enum CavaloEnum {
    IMPERATRIZ("Imperatriz"),
    DUQUE("Duque"),
    PRINCESA("Princesa (vc sabe quem)"),
    PE("Pé de Pano"),
    PANGARE("Pangaré");

    private String nomeCavalo;
    CavaloEnum(String nomeCavalo){
        this.nomeCavalo = nomeCavalo;
    }

    public String getNomeCavalo() { return this.nomeCavalo;}

    public static CavaloEnum cavaloEscolhido(int i){
        if (i == 0) {
            return IMPERATRIZ;
        } else if(i == 1) {
            return DUQUE;
        } else if(i == 2){
            return PRINCESA;
        } else if(i == 3){
            return PE;
        } else{
            return PANGARE;
        }
    }
}
