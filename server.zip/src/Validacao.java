public class Validacao {
    public boolean vencedorCorrida(String apostado1, String nomeCavalo, long tempoCavalo, int valorAposta) {
        String cavaloVencedor = "O cavalo: " + nomeCavalo + " Venceu ! Tempo: " + tempoCavalo + "s";
        String apostadorVencedor = "";

        if (nomeCavalo.equals(apostado1)) {
            valorAposta *= 2;
            apostadorVencedor = "Apostador 1 ganhou a aposta!! valor: " + valorAposta;
        } else {
            apostadorVencedor = "O apostador perdeu a aposta";
        }
        System.out.println(cavaloVencedor + "  |  " + apostadorVencedor);
        return true;
    }
}